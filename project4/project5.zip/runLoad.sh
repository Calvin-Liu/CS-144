#!/bin/bash

ant clean
ant compile
ant build
ant deploy
