#!/bin/bash

mysql CS144 < dropSQLIndex.sql
mysql CS144 < buildSQLIndex.sql

ant run
