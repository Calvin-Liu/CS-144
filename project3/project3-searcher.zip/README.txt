Calvin Liu
804182525

Nothing to add here, implemented the functions and works on browser
